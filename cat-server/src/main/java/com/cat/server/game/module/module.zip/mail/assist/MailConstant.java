package com.cat.server.game.module.mail.assist;

public class MailConstant {
	
	/**
	 * 默认过期时间
	 */
	public static int expiredDays = 15;

}
