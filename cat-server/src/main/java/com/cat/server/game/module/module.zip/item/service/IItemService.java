package com.cat.server.game.module.item.service;

/**
 * 背包接口
 * @author Administrator
 *
 */
public interface IItemService {

}
