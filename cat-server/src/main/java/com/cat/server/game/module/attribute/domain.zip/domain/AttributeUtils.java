package com.cat.server.game.module.attribute.domain;

public class AttributeUtils {
	
	public static AttributeDictionary EMPTY = new AttributeDictionary();

}
