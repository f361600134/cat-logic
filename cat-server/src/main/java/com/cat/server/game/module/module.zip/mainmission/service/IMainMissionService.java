package com.cat.server.game.module.mainmission.service;

public interface IMainMissionService {

}
