package com.cat.server.game.module.rank.type;

import java.util.Collection;

import com.cat.net.network.base.IProtocol;
import com.cat.server.game.data.proto.PBRank.PBRankDto;
import com.cat.server.game.module.rank.domain.Rank;
import com.cat.server.game.module.rank.domain.RankTypeEnum;

public interface IRankNewType{
	
	/**
	 * 排行榜类型
	 * @return 返回排行榜枚举类型
	 */
	public RankTypeEnum rankTypeEnum();
	
	/**
	 * 当排行榜刷新,新入榜即刷新
	 * @param rank 新增的/修改的排行榜对象
	 */
	public void onRefresh(Rank rank);
	
	/**
	 * 根据唯一id获取到排名
	 * @param uniqueId
	 * @return 返回排名
	 */
	public int getRanking(long uniqueId);
	
	/**
	 * 获取当前排行榜信息
	 * @return 返回排行榜列表
	 */
	public Collection<Rank> getRankInfo();
	
	/**
	 * 构建排行榜消息对象
	 * @param rank 排行榜对象转排行榜协议对象
	 * @return 返回排行榜协议对象
	 */
	public PBRankDto buildRankDto(Rank rank);
	
	/**
	 * 构建排行榜消息
	 * @return 返回排行榜列表消息
	 */
	public IProtocol buildProtocol(long uniqueId);

}
