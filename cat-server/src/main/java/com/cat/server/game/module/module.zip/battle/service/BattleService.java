package com.cat.server.game.module.battle.service;

import org.springframework.stereotype.Service;

@Service
public class BattleService implements IBattleService{

	@Override
	public void fight(long attackId, long defencerId) {
		
	}
	
	

}
