package com.cat.server.game.module.hero.controller;

import org.springframework.stereotype.Controller;

@Controller
public class HeroController {

}
