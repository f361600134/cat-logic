package com.cat.server.game.module.battle.domain;

public class BattleDomain {

}
