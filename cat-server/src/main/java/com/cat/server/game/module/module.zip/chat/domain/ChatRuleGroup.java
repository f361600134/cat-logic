package com.cat.server.game.module.chat.domain;

import java.util.Map;

public class ChatRuleGroup {
	
	private Map<Long, ChatRule> chatRuleMap;
	
	

}
