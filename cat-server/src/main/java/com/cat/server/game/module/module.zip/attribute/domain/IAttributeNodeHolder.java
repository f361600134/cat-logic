package com.cat.server.game.module.attribute.domain;

/**
 * 属性节点持有者
 */
public interface IAttributeNodeHolder {

    IAttributeNode getAttributeNode();
    
}
