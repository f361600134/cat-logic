package com.cat.server.game.module.hero.manager;

import com.cat.server.core.server.AbstractModuleManager;
import com.cat.server.game.module.hero.domain.HeroDomain;
import org.springframework.stereotype.Component;

@Component
public class HeroManager extends AbstractModuleManager<Long,HeroDomain>{
	
}
