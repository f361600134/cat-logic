package com.cat.server.game.module.playermail.domain;

import com.cat.server.core.server.AbstractModuleMultiDomain;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
* PlayerMailDomain
* @author Jeremy
*/

public class PlayerMailDomain extends AbstractModuleMultiDomain<Long, Integer, PlayerMail> {

	private static final Logger log = LoggerFactory.getLogger(PlayerMailDomain.class);
	
	
	public PlayerMailDomain(){
		
	}

	
	////////////业务代码////////////////////
	
	
}

